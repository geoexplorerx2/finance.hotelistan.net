<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make("layouts.head_box_purchasing", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12 table-responsive">
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row pb-3">
                            <div class="col-lg-4">
                                <label for="startDate">Başlangıç Tarihi</label>
                                <input type="text" class="form-control datepicker" id="startDate" name="startDate" placeholder="Başlangıç Tarihi" value="<?php echo e($start); ?>" autocomplete="off" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="endDate">Bitiş Tarihi</label>
                                <input type="text" class="form-control datepicker" id="endDate" name="endDate" placeholder="Bitiş Tarihi" autocomplete="off" value="<?php echo e($end); ?>" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="endDate">Firma</label>
                                <select name="companyId" class="form-control" id="companyId">
                                    <option></option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <button class="btn btn-success mt-3 float-right" type="submit">Filtrele <i class="fa fa-check"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card p-3 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Bekleyen Satın Alma Taleplerim</h3>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create payment request')): ?>
                            <a href="<?php echo e(route('purchasingrequests.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Talep Oluştur</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mt-3">
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <?php echo $html->table(); ?>

               </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $html->scripts(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/purchasingrequests/purchasing_request_list.blade.php ENDPATH**/ ?>