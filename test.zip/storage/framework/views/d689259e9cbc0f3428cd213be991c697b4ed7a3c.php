<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-dark d-inline-block mb-0 item-text">Arayüz</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-12 col-md-6">
                        <div class="card card-stats">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-dashboard-card">Bugün Ödenmesi Gereken Taleplerim</h5>
                                        <hr>
                                        <span class="h2 mb-0 count-card"><?php echo e($requestedPaymentRequestTodayCount); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-danger text-white rounded-circle shadow">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-12 col-md-6">
                        <div class="card card-stats">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-dashboard-card">Bugün Tamamlanan Ödeme Taleplerim</h5>
                                        <hr>
                                        <span class="h2 mb-0 count-card"><?php echo e($completedPaymentRequestTodayCount); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-success text-white rounded-circle shadow">
                                            <i class="fa fa-check"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-12 col-md-6">
                        <div class="card card-stats">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-dashboard-card">Toplam Cevaplanmayan Ödeme Taleplerim</h5>
                                        <hr>
                                        <span class="h2 mb-0 count-card"><?php echo e($allRequestedPaymentRequestCount); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-danger text-white rounded-circle shadow">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-12 col-md-6">
                        <div class="card card-stats">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-dashboard-card">Toplam Tamamlanan Ödeme Taleplerim</h5>
                                        <hr>
                                        <span class="h2 mb-0 count-card"><?php echo e($allCompletedPaymentRequestCount); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-success text-white rounded-circle shadow">
                                            <i class="fa fa-check"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 table-responsive">
                    <div class="card p-4 mt-3">
                        <div class="card-title">
                            <h2>Bugün Ödenmesi Gereken Taleplerim</h2>
                            <hr>
                        </div>
                        <div class="dt-responsive table-responsive">
                            <table class="table table-striped table-bordered nowrap dataTable" id="tableData">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">İşlem</th>
                                        <th scope="col">ID</th>
                                        <th scope="col">Durum</th>
                                        <th scope="col">Firma Adı</th>
                                        <th scope="col">Vade</th>
                                        <th scope="col">Tutar</th>
                                        <th scope="col">Belge No</th>
                                        <th scope="col">Belge Tarihi</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $requestedPaymentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requestedPaymentRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle action-btn" type="button" data-toggle="dropdown">İşlem <span class="caret"></span></button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a href="<?php echo e(url('/definitions/paymentrequests/edit/'.$requestedPaymentRequest->id.'')); ?>" class="btn btn-info edit-btn"><i class="fa fa-pencil-square-o"></i> Güncelle</a>
                                                    </li>           
                                                    <li>
                                                        <a href="<?php echo e(url('/definitions/paymentrequests/destroy/'.$requestedPaymentRequest->id.'')); ?>" onclick="return confirm(Are you sure?);" class="btn btn-danger edit-btn"><i class="fa fa-trash"></i> Sil</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                        <td><?php echo e(date('ymd', strtotime($requestedPaymentRequest->created_at)) . $requestedPaymentRequest->id); ?></td>
                                        <td><span class="badge badge-danger"><?php echo e($requestedPaymentRequest->status->status_name); ?></span></td>
                                        <td><?php echo e($requestedPaymentRequest->companies->company_name); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($requestedPaymentRequest->expiry_date))); ?></td>
                                        <td><?php echo e($requestedPaymentRequest->payment_amount . ' ' . $requestedPaymentRequest->payment_amount_currency); ?></td>
                                        <td><?php echo e($requestedPaymentRequest->document_no); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($requestedPaymentRequest->document_date))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 table-responsive">
                    <div class="card p-4 mt-3">
                        <div class="card-title">
                            <h2>Bugün Tamamlanan Ödeme Taleplerim</h2>
                            <hr>
                        </div>
                        <div class="dt-responsive table-responsive">
                            <table class="table table-striped table-bordered nowrap dataTable" id="tableCompleted">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Operation</th>
                                        <th scope="col">ID</th>
                                        <th scope="col">Durum</th>
                                        <th scope="col">Firma Adı</th>
                                        <th scope="col">Vade</th>
                                        <th scope="col">Tutar</th>
                                        <th scope="col">Belge No</th>
                                        <th scope="col">Belge Tarihi</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $completedPaymentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completedPaymentRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(url('/salesadmin/treatmentplan/edit/'.$completedPaymentRequest->id)); ?>" class="btn btn-danger treatmentplan-next-btn">Complete TP <i class="fa fa-chevron-right"></i></a>
                                        </td>
                                        <td><?php echo e(date('ymd', strtotime($completedPaymentRequest->created_at)) . $completedPaymentRequest->id); ?></td>
                                        <td><span class="badge badge-danger"><?php echo e($completedPaymentRequest->status->status_name); ?></span></td>
                                        <td><?php echo e($completedPaymentRequest->companies->company_name); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($completedPaymentRequest->expiry_date))); ?></td>
                                        <td><?php echo e($completedPaymentRequest->payment_amount . ' ' . $completedPaymentRequest->payment_amount_currency); ?></td>
                                        <td><?php echo e($completedPaymentRequest->document_no); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($completedPaymentRequest->document_date))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/financeadmin/home.blade.php ENDPATH**/ ?>