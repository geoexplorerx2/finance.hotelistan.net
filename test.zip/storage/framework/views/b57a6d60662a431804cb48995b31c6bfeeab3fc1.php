<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Önceki Sayfa</button>
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Ödeme Talebi Durumunu Güncelle</h2>
                </div>
                <form action="<?php echo e(url('/definitions/paymentrequeststatus/update/'.$payment_request_statuses->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="status_name">Ödeme Talebi Durumu Adı</label>
                                <input type="text" class="form-control" id="status_name" name="status_name" placeholder="Ödeme Talebi Durumu Adı" value="<?php echo e($payment_request_statuses->name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="status_color">Ödeme Talebi Durumu Rengi</label>
                                <input type="text" class="form-control" id="status_color" data-jscolor="{}" name="status_color" placeholder="Ödeme Talebi Durumu Rengi" value="<?php echo e($payment_request_statuses->color); ?>" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-5 float-right">Güncelle <i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/paymentrequeststatus/edit_payments_status.blade.php ENDPATH**/ ?>