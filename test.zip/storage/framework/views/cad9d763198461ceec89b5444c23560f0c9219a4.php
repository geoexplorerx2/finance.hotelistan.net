<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make("layouts.head_box_purchasing", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12 table-responsive">
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row pb-3">
                            <div class="col-lg-4">
                                <label for="startDate">Başlangıç Tarihi</label>
                                <input type="text" class="form-control datepicker" id="startDate" name="startDate" placeholder="Başlangıç Tarihi" value="<?php echo e($start); ?>" autocomplete="off" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="endDate">Bitiş Tarihi</label>
                                <input type="text" class="form-control datepicker" id="endDate" name="endDate" placeholder="Bitiş Tarihi" autocomplete="off" value="<?php echo e($end); ?>" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="supplierId">Tedarikçi</label>
                                <select name="supplierId" class="form-control" id="supplierId">
                                    <option></option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <button class="btn btn-success mt-3 float-right" type="submit">Filtrele <i class="fa fa-check"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card p-3 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Cevaplanmayan Satın Alma Talepleri</h3>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ödeme talebi oluştur')): ?>
                            <a href="<?php echo e(route('purchasingrequests.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Talep Oluştur</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mt-3">
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <div class="card-body">
                        <table id="newTable" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>İşlem</th>
                                    <th>id</th>
                                    <th>Durum</th>
                                    <th>Ürün Başlığı</th>
                                    <th>Ürün Linki</th>
                                    <th>Tedarikçi Adı</th>
                                    <th>Oluşturulma Tarihi</th>
                                    <th>Oluşturan</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th style="display: table-column;">İşlem</th>
                                    <th>id</th>
                                    <th>Durum</th>
                                    <th>Ürün Başlığı</th>
                                    <th>Ürün Linki</th>
                                    <th>Tedarikçi Adı</th>
                                    <th>Oluşturulma Tarihi</th>
                                    <th>Oluşturan</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $purchasing_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasing_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row" class="odd">
                                        <td class="">
                                            <a href="/purchasingrequests/edit/<?php echo e($purchasing_request->id); ?>" class="badge badge-danger">Cevapla <i class="fa fa-chevron-right icon-sm white" aria-hidden="true"></i></a>
                                        </td>
                                        <td><?php echo e(date('ymd', strtotime($purchasing_request->created_at)) . $purchasing_request->id); ?></td>
                                        <td style="background-color: <?php echo e($purchasing_request->status->color); ?>;color:white"><?php echo e($purchasing_request->status->name); ?></td>
                                        <td><?php echo e($purchasing_request->product_title); ?></td>
                                        <td><?php echo e($purchasing_request->product_url); ?></td>
                                        <td><?php echo e($purchasing_request->suppliers->name); ?></td>
                                        <td><?php echo e(date('Y-m-d', strtotime($purchasing_request->created_at))); ?></td>
                                        <td><?php echo e($purchasing_request->user->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/purchasingrequests/requested.blade.php ENDPATH**/ ?>