<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make("layouts.head_box", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12 table-responsive">
            <div class="card mt-3">
                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row pb-3">
                            <div class="col-lg-4">
                                <label for="startDate">Başlangıç Tarihi</label>
                                <input type="text" class="form-control datepicker" id="startDate" name="startDate" placeholder="Başlangıç Tarihi" value="<?php echo e($start); ?>" autocomplete="off" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="endDate">Bitiş Tarihi</label>
                                <input type="text" class="form-control datepicker" id="endDate" name="endDate" placeholder="Bitiş Tarihi" autocomplete="off" value="<?php echo e($end); ?>" required>
                            </div>
                            <div class="col-lg-4">
                                <label for="endDate">Firma</label>
                                <select name="companyId" class="form-control" id="companyId">
                                    <option></option>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <button class="btn btn-success mt-3 float-right" type="submit">Filtrele <i class="fa fa-check"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card p-4 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Ödenmeyen Ödeme Talepleri</h3>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ödeme talebi oluştur')): ?>
                            <a href="<?php echo e(route('paymentrequests.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Talep Oluştur</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <table id="newTable" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>İşlem</th>
                                <th>id</th>
                                <th>Durum</th>
                                <th>Kategori</th>
                                <th>Firma "Paid" Adı</th>
                                <th>Firma "Pay" Adı</th>
                                <th>Vade</th>
                                <th>Tutar</th>
                                <th>Belge No</th>
                                <th>Belge Tarihi</th>
                                <th>Fatura Tarihi</th>
                                <th>Açıklama</th>
                                <th>Oluşturan</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th style="display: table-column;">İşlem</th>
                                <th>id</th>
                                <th>Durum</th>
                                <th>Kategori</th>
                                <th>Firma "Paid" Adı</th>
                                <th>Firma "Pay" Adı</th>
                                <th>Vade</th>
                                <th>Tutar</th>
                                <th>Belge No</th>
                                <th>Belge Tarihi</th>
                                <th>Fatura Tarihi</th>
                                <th>Açıklama</th>
                                <th>Oluşturan</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $payment_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="odd">
                                    <td class="">
                                        <a href="/paymentrequests/edit/<?php echo e($payment_request->id); ?>" class="badge badge-danger">Cevapla <i class="fa fa-chevron-right icon-sm white" aria-hidden="true"></i></a>
                                    </td>
                                    <td><?php echo e(date('ymd', strtotime($payment_request->created_at)) . $payment_request->id); ?></td>
                                    <td style="background-color: <?php echo e($payment_request->status->color); ?>;color:white"><?php echo e($payment_request->status->name); ?></td>
                                    <td style="background-color: <?php echo e($payment_request->category->color); ?>;color:white"><?php echo e($payment_request->category->name); ?></td>
                                    <td><?php echo e($payment_request->paidCompanies->name); ?></td>
                                    <td><?php echo e($payment_request->payCompanies->name); ?></td>
                                    <td><?php echo e($payment_request->expiry_date); ?></td>
                                    <td><?php echo e(number_format($payment_request->payment_amount, 2)); ?> <?php echo e($payment_request->payment_amount_currency); ?></td>
                                    <td><?php echo e($payment_request->document_no); ?></td>
                                    <td><?php echo e($payment_request->document_date); ?></td>
                                    <td><?php echo e($payment_request->invoice_date); ?></td>
                                    <td><?php echo e($payment_request->note); ?></td>
                                    <td><?php echo e($payment_request->user->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/paymentrequests/requested.blade.php ENDPATH**/ ?>