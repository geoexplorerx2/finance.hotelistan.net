<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary mt-3" onclick="previousPage();"><i class="fa fa-chevron-left"></i> Önceki Sayfa</button>
            <div class="card p-3 mt-3">
                <div class="card-title">
                    <p class="text-white tp-status" style="background-color: <?php echo e($payment_request->status->color); ?>;padding: 15px; border-radius: 10px;">Ödeme Talebi Durumu: <strong><?php echo e($payment_request->status->name); ?></strong></p>
                    <nav class="nav nav-borders">
                        <a class="nav-link active ms-0" href="<?php echo e(route('paymentrequests.edit', ['id' => $payment_request->id])); ?>"><i class="fa fa-user" style="margin-right:5px;"></i> Ödeme Talep Bilgileri</a>
                        <a class="nav-link ms-0" href="<?php echo e(route('paymentrequests.edit', ['id' => $payment_request->id,'page'=>'files'])); ?>"><i class="fa fa-file" style="margin-right:5px;"></i> Belgeler</a>
                    </nav>
                </div>
                <div class="row">
                    <div class="col-xl-3">
                        <div class="card mb-4 mb-xl-0">
                            <div class="card-header">Firma Bilgileri</div>
                            <div class="card-body text-center">
                                <img class="img-account-profile rounded-circle mb-2" src="<?php echo e(asset('assets/img/user.png')); ?>" alt="">
                                <div class="small font-italic text-muted patient-name mb-4"><?php echo e($payment_request->companies->company_name); ?></div>
                                <hr>
                                <div class="row pb-2 pt-2">
                                    <div class="col-12 col-lg-6">
                                        <h4 class="mb-0 text-left"><b><?php echo e($payment_request->user->name); ?></b></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <div class="card">
                            <div class="card-body">
                                <form action="<?php echo e(route('paymentrequests.update',['id'=>$payment_request->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="expiryDate">Vade</label>
                                                    <input type="text" class="form-control" id="expiryDate" name="expiryDate" placeholder="Vade" value="<?php echo e($payment_request->expiry_date); ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="paymentAmount">Tutar</label>
                                                    <input type="text" class="form-control" id="paymentAmount" name="paymentAmount" placeholder="Tutar" value="<?php echo e($payment_request->payment_amount); ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="paymentCurrency">Para Birimi</label>
                                                    <select class="form-control" id="paymentCurrency" name="paymentCurrency">
                                                        <option value="<?php echo e($payment_request->payment_amount_currency); ?>" selected><?php echo e($payment_request->payment_amount_currency); ?></option>
                                                        <option value="EUR">EUR</option>
                                                        <option value="USD">USD</option>
                                                        <option value="GBP">GBP</option>
                                                        <option value="TL">TL</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="companyId">Firma</label>
                                                    <select class="form-control" id="companyId" name="companyId" required>
                                                        <option value="<?php echo e($payment_request->company_id); ?>" selected><?php echo e($payment_request->companies->name); ?></option>
                                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="paymentTypeId">Ödeme Türleri</label>
                                                    <select class="form-control" id="paymentTypeId" name="paymentTypeId" required>
                                                        <option value="<?php echo e($payment_request->payment_type_id); ?>" selected><?php echo e($payment_request->paymentType->name); ?></option>
                                                        <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($payment_type->id); ?>"><?php echo e($payment_type->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="documentNo">Belge No</label>
                                                    <input type="text" class="form-control" id="documentNo" name="documentNo" placeholder="Belge No" value="<?php echo e($payment_request->document_no); ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="documentDate">Belge Tarihi</label>
                                                    <input type="text" class="form-control" id="documentDate" name="documentDate" placeholder="Belge Tarihi" value="<?php echo e($payment_request->document_date); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="invoiceDate">Fatura Tarihi</label>
                                                    <input type="text" class="form-control" id="invoiceDate" name="invoiceDate" placeholder="Fatura Tarihi" value="<?php echo e($payment_request->invoice_date); ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="note">Açıklama</label>
                                                    <textarea class="form-control" id="note" name="note" placeholder="Açıklama" rows="3" cols="50"><?php echo e($payment_request->note); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-success mt-5 float-right" id="updatePaymentRequestModalBtn" data-toggle="modal" data-target="#postModal"><?php if($payment_request->payment_request_status_id == 1): ?> Cevapla <?php elseif($payment_request->payment_request_status_id == 2): ?> Güncelle <?php endif; ?> <i class="fa fa-check"></i></button>
                                        <button type="submit" class="btn btn-primary mt-5 float-right mr-2">Güncelle</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="postModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ödeme Talebini Cevapla</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="row">
                        <input type="hidden" id="payment_request_id" value="<?php echo e($payment_request->id); ?>">
                        <div class="col-lg-12">
                            <label for="paymentRequestStatusId" style="width: 100%;">Ödeme Durumu</label>
                            <select class="form-control" id="paymentRequestStatusId">
                                <option></option>
                                <?php if($payment_request->payment_request_status_id != ""): ?>
                                    <?php $__currentLoopData = $payment_request_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_request_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($payment_request_status->payment_request_status_id == $payment_request_status->id): ?>
                                            <option value="<?php echo e($payment_request_status->id); ?>" selected><?php echo e($payment_request_status->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php $__currentLoopData = $payment_request_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_request_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($payment_request_status->id); ?>"><?php echo e($payment_request_status->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-12 mt-3">
                            <label for="note">Not</label>
                            <textarea class="form-control" id="note" placeholder="Not"><?php echo e($payment_request->answer_note); ?></textarea>
                        </div>
                        <div class="col-lg-12 mt-3">
                            <button class="btn btn-success float-right" id="postRequest">Cevapla <i class="fa fa-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/paymentrequests/edit_payment_request.blade.php ENDPATH**/ ?>