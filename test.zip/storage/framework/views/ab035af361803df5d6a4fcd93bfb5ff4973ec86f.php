<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Firmayı Güncelle</h2>
                    <p class="float-right last-user">Ekleyen Kullanıcı: <i class="fa fa-user text-dark"></i> <?php echo e($company->user->name); ?></p>
                </div>
                <form action="<?php echo e(route('companies.update',['id'=>$company->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="name">Firma Adı</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Firma Adı" value="<?php echo e($company->name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="bankName">Firma Banka Adı</label>
                                <input type="text" class="form-control" id="bankName" name="bankName" placeholder="Firma Banka Adı" value="<?php echo e($company->bank_name); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="bankIban">Firma Banka İbanı</label>
                                <input type="text" class="form-control" id="bankIban" name="bankIban" placeholder="Firma Banka İbanı" value="<?php echo e($company->bank_iban); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="personName">Firma Yetkili Adı</label>
                                <input type="text" class="form-control" id="personName" name="personName" placeholder="Firma Yetkili Adı" value="<?php echo e($company->person_name); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="ExpiryDate">Vade</label>
                                <input type="text" class="form-control" id="ExpiryDate" name="ExpiryDate" value="<?php echo e($company->expiry_date); ?>" placeholder="Vade">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label for="paymentTypeID">Ödeme Türü</label>
                            <select name="paymentTypeID" class="form-control" id="paymentTypeID">
                                <option value="<?php echo e($company->paymentType->id); ?>"><?php echo e($company->paymentType->name); ?></option>
                                <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($payment_type->id); ?>"><?php echo e($payment_type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="phoneNumber">Firma İletişim Numarası</label>
                                <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" placeholder="Firma Yetkili Adı" value="<?php echo e($company->phone_number); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="note">Açıklama</label>
                                <textarea class="form-control" name="note" id="note" placeholder="Açıklama" rows="3" cols="50"><?php echo e($company->note); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-5 float-right">Güncelle<i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/companies/edit_company.blade.php ENDPATH**/ ?>