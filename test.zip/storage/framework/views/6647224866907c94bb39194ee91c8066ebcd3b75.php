<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 table-responsive">
            <button class="btn btn-primary mt-3" onclick="previousPage();"><i class="fa fa-chevron-left" aria-hidden="true"></i> Önceki Sayfa</button>
            <div class="card p-7 mt-3">
                <div class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h2><?php echo e($tableTitle); ?></h2>
                        </div>
                        <div class="col-md-6">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create payment request')): ?>
                            <a href="<?php echo e(route('paymentrequests.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Talep</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap dataTable" id="dataTable">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">İşlem</th>
                                <th scope="col">Durum</th>
                                <th scope="col">Firma Adı</th>
                                <th scope="col">Vade</th>
                                <th scope="col">Tutar</th>
                                <th scope="col">Belge No</th>
                                <th scope="col">Belge Tarihi</th>
                                <th scope="col">Fatura Tarihi</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $listAllByDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listAllByDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle action-btn" type="button" data-toggle="dropdown">İşlem <span class="caret"></span></button>
                                        <ul class="dropdown-menu">
                                            <li style="margin:10px;">
                                                <a href="<?php echo e(route('paymentrequests.edit',['id'=> $listAllByDate->pId])); ?>" class="btn btn-info edit-btn inline-popups"><i class="fa fa-pencil-square-o" style="padding:7px;"></i> Güncelle</a>
                                            </li>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete payment request')): ?>
                                            <li style="margin:10px;">
                                                <a href="<?php echo e(route('paymentrequests.destroy',['id'=>$listAllByDate->pId])); ?>" onclick="return confirm('Silmek istediğinize emin misiniz?');" class="btn btn-danger edit-btn"><i class="far fa-trash-alt" style="padding:7px;"></i> Sil</a>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                                <td><span class="badge text-white" style="background-color: <?php echo e($listAllByDate->color); ?>"><?php echo e($listAllByDate->name); ?></span></td>
                                <td><?php echo e($listAllByDate->cName); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($listAllByDate->expiry_date))); ?></td>
                                <td><?php echo e(number_format($listAllByDate->payment_amount, 2) . ' ' . $listAllByDate->payment_amount_currency); ?></td>
                                <td><?php echo e($listAllByDate->document_no); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($listAllByDate->document_date))); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($listAllByDate->invoice_date))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
               </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/paymentrequests/all_paymentrequest.blade.php ENDPATH**/ ?>