<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 mt-3">
                <div class="card-title">
                    <h2>Kredi Kart Güncelle</h2>
                    <p class="float-right last-user">Ekleyen Kullanıcı: <i class="fa fa-user text-dark"></i> <?php echo e($creditcard->user->name); ?></p>
                </div>
                <form action="<?php echo e(route('creditcards.update',['id'=>$creditcard->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="creditCardName">Kart Adı</label>
                                <input type="text" class="form-control" id="creditCardName" name="creditCardName" placeholder="Kart Adı" value="<?php echo e($creditcard->name); ?>" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="creditCardNumber">Kart Numarası</label>
                                <input type="text" class="form-control" id="creditCardNumber" name="creditCardNumber" value="<?php echo e($creditcard->number); ?>" placeholder="Kart Numarası">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="expiry_date">Bitiş Tarihi</label>
                                <input type="text" class="form-control" id="expiry_date" name="expiry_date" value="<?php echo e($creditcard->expiry_date); ?>" placeholder="10-29">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="cvv">CVV</label>
                                <input type="text" class="form-control" id="cvv" name="cvv" value="<?php echo e($creditcard->cvv); ?>" placeholder="CVV">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="creditCardCurrency">Para Birimi</label>
                                <select class="form-control" id="creditCardCurrency2" name="creditCardCurrency">
                                    <option value="<?php echo e($creditcard->currency); ?>" selected><?php echo e($creditcard->currency); ?></option>
                                    <option value="EUR">EUR</option>
                                    <option value="USD">USD</option>
                                    <option value="GBP">GBP</option>
                                    <option value="TL">TL</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-5 float-right">Güncelle<i class="fa fa-check" aria-hidden="true"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/enes/Desktop/works/hotelistan/financecrm/resources/views/admin/creditcards/edit_creditcard.blade.php ENDPATH**/ ?>