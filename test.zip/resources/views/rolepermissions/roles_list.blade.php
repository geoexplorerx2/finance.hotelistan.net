@extends('layouts.app')

@section('content')

@include('layouts.navbar')






@endsection
